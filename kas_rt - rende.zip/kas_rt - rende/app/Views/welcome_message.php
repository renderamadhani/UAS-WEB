<?= $this->extend('master'); ?>

<?= $this->section('content'); ?>

<h1 class="text-center text-capitalize mt-4">Selamat datang di aplikasi kas RT</h1>

<img src="<?= base_url() ?>/img/gambar.svg" alt="" width="400px" class="d-block mx-auto mt-4">

<?= $this->endSection(); ?>