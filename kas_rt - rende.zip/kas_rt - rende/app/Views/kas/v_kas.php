<?= $this->extend('master'); ?>

<?= $this->section('content'); ?>

<h1>Hello</h1>

<?= $this->endSection(); ?>